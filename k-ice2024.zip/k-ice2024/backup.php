
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Download PDF Files</title>
  <style>

 table {
  width: 80%; 
  margin: 0 auto;
  border-collapse: collapse;
   background-color: #f2f2f2;
}
th, td {
  border: 1px solid #dddddd;
 
   text-align: center; /* Horizontal centering */
            vertical-align: middle; /* Vertical centering */
  padding: 8px;
}   

 
  

.center {
  	margin-left: auto;
  	margin-right: auto;
}

#nested {
  	background-color: #EEEEEE;
  	  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}




body               { 
  background:#aaa; 
  font:400 14px 'Calibri','Arial';
  padding:20px 0px 20px; 
  margin: 0;
    
    /*  display: flex;  */
      justify-content: center;
      align-items: center;
      height: 100vh; /* Full height of the viewport */
}

blockquote {
  color:white;
  text-align:center;
}


.container {
  background-color: #ddd;
  background-image: -moz-linear-gradient(#eee,#ddd);
  background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));    
  background-image: -webkit-linear-gradient(#eee, #ddd);
  background-image: -o-linear-gradient(#eee, #ddd);
  background-image: -ms-linear-gradient(#eee, #ddd);
  background-image: linear-gradient(#eee, #ddd);
  margin-top: -30px;
  padding-top: 30px;
  -moz-border-radius: 5px 5px 0 0;
  -webkit-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;     
}


.container1 {
  background-color: #ddd;
  background-image: -moz-linear-gradient(#eee,#ddd);
  background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));    
  background-image: -webkit-linear-gradient(#eee, #ddd);
  background-image: -o-linear-gradient(#eee, #ddd);
  background-image: -ms-linear-gradient(#eee, #ddd);
  background-image: linear-gradient(#eee, #ddd);
  margin-top: -30px;
  padding-top: 30px;
  -moz-border-radius: 5px 5px 0 0;
  -webkit-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;  
  width:99%;
}

.h3 {
  background-color: #ddd;
  background-image: -moz-linear-gradient(#eee,#ddd);
  background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));    
  background-image: -webkit-linear-gradient(#eee, #ddd);
  background-image: -o-linear-gradient(#eee, #ddd);
  background-image: -ms-linear-gradient(#eee, #ddd);
  background-image: linear-gradient(#eee, #ddd);
  margin-top: -30px;
  padding-top: 30px;
  -moz-border-radius: 5px 5px 0 0;
  -webkit-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;     
}

 .responsive-image {
       max-width: 100%; /* Ensure image is responsive */
      height: auto;
      display: block; /* Remove extra space below the image */
       align-items: center;
      /*  background-color: #ddd; */
        display: flex;
    }
    
    .image-container {
  max-width: 100%; /* Adjust as needed */
  margin: 0 auto; /* Center the container */
   align-items: center;
       /*  background-color: #ddd; */
}



/* Footer Image Styling -->  */

    .responsive-footer-image {
        max-width: 80%; /* Limit max width for the footer */
        width: 100%; /* Responsive width */
        height: auto; /* Maintain aspect ratio */
        display: block; /* Remove extra space below the image */
        margin: 0 auto; /* Center the image in the footer */
         background-color: #ddd;
    }



        .dashed-hr {
            border: none;
            border-top: 2px dashed #2e86c1; /* Dashed line with color */
            margin: 20px 0;
        }

        .shadow-hr {
            border: none;
            height: 2px;
            background-color: #2e86c1;
            box-shadow: 0 2px 10px -2px rgba(0, 0, 0, 0.5); /* Add shadow for a 3D effect */
            margin: 20px 0;
        }










  </style>
  
  
  <?php
    // Define the image path
    $imagePathlogo = 'files/50-logo.jpg';
    $imagePathwording = 'files/50-wording.png';
    $imagePathbanner = 'files/50-footer.jpg';
    $imagePathfooter = 'files/organizer3.png';

    // Check if the file exists before displaying it
    if (file_exists($imagePath)) {
        echo '<img src="' . $imagePathlogo . '" alt="Responsive Image" class="responsive-image">';
    } else {
        echo '<p>Image not found.</p>';
    }
    
    
    // Check if the file exists before displaying it
    if (file_exists($imagePathbanner)) {
        echo '<img src="' . $imagePathbanner . '" alt="Responsive Image" class="responsive-image">';
    } else {
        echo '<p>Image not found.</p>';
    }
    
    
    
    // Check if the file exists before displaying it
    if (file_exists($imagePathfooter)) {
        echo '<img src="' . $imagePathfooter . '" alt="Responsive Image" class="responsive-image">';
    } else {
        echo '<p>Image not found.</p>';
    }
    
    
     // Check if the file exists before displaying it
    if (file_exists($imagePathwording)) {
        echo '<img src="' . $imagePathwording . '" alt="Responsive Image" class="responsive-image">';
    } else {
        echo '<p>Image not found.</p>';
    }
?>
  
  
  
</head>
<body>
    
    
        <hr class="dashed-hr">
    <p>Content below the dashed horizontal line.</p>

    <hr class="shadow-hr">
    <p>Content below the shadowed horizontal line.</p>

<div class="h3"> 

            <table style="background-color:;  padding: 0px;  "> 
            
            <tr> 
            
            <td style="width:20%">
                
                     <br>
                    
                    <img src="files/50-logo.jpg" alt="Responsive Image" class="responsive-image" >
                
            </td>
            
            
            <td style="width:60%">
                
            
                    
             
                    <img src="files/50-wording.png" alt="Responsive Image" class="responsive-image" >
                     
                    
                    
            
                
                
            </td>
            <td style="width:20%">
                
                <br>
                    
            
                    <img src="files/organizer3.png" alt="Responsive Image" class="responsive-image">
                      
                
            </td>
            
            </tr>
            </table>

</div>
<br>




    
   </div>
    <div class="container">
        
          
        	<table>
        	    
        	    
        	
        	    
        	      <caption>    <h1>Kuantan Port International Conference 2024 <span>K-ICe 2024</span></h1></caption>
        	    
  <br>
  <br>
  
    <caption>    <h3>Document Download according to Conference Session </span></h3></caption>
				<tr>
				    <th id="nested" style:"width:10%;">Number</th>
  					<th id="nested">Document Names</th>
  					<th id="nested">Link</th>
  				</tr>
  				<tr>
  					<td>1</td>
  					<td>aaaaa</td>
  					<td>aaaaa</td>
  					
  				</tr>
  				<tr>
  					<td>1</td>
  					<td>aaaaa</td>
  					<td>aaaaa</td>
  					
  				</tr>
  				<tr>
  					<td>1</td>
  					<td>aaaaa</td>
  					<td>aaaaa</td>
  					
  				</tr>
  				<tr>
  					<td>1</td>
  					<td>aaaaa</td>
  					<td>aaaaa</td>
  					
  				</tr>
  				
  			</table>
        
  
        

    <br>
  
  
  <table>
      
      <caption>Annual Sales Report</caption>
      
  <tr>
    <th scope="col">Fruit</th>
    <th scope="col">Quantity</th>
    <th scope="col">images</th>
  </tr>
  <tr>
    <td>Bananas</td>
    <td>1500</td>
   <td><img src="orange.jpg" alt="Orange" width="60" height="60"></td>
  </tr>
  <tr>
    <td>Apples</td>
    <td>2000</td>
     <td><img src="orange.jpg" alt="Orange" width="60" height="60"  class="img-fluid img-thumbnail" alt="Sheep"></td>
  </tr>
</table>
  
  <br>
  
   <table class="center">
      
       <td colspan="2">Merged Cell</td>
<td rowspan="2">Also Merged Cell</td> 

  <colgroup>
	<col>
  	<col>
	<col>
	<col>
  </colgroup>
  <tr>
  	<th>Name</th>
  	<th>Job Title</th>
  	<th>Email address</th>
  		<th>Download / View</th>
  </tr>
  <tr>
  	<td>Anna Fitzgerald</td>
  	<td>Staff Writer</td>
 	<td>example@company.com</td>
 		<td>example@company.com</td>
  </tr>
  <tr>
  	<td>John Smith</td>
  	<td>Marketing Manager</td>
  	<td>example2@company.com</td>
  		<td>  <a class="download-button" href="files/doc.docx" download>Download</a></td>
  </tr>
  <tr>
  	<td>Zendaya Grace</td>
  	<td>CEO</td>
  	<td>example2@company.com</td>
  		<td>example@company.com</td>
  			<td><a class="download-button" href="files/pdf1.pdf" download>Download</a></td>
  		
  		<td>	
  		
  		<table>
  		      <h3>Professional<span>$29</span></h3>
				<tr>
  					<th id="nested">Home Phone</th>
  					<th id="nested">Cell Phone</th>
  				</tr>
  				<tr>
  					<td>888-888-880</td>
  					<td>888-888-881</td>
  				</tr>
  			</table>
  </td>
  
  </tr>
</table>
  
  <br>
  
 
       </div>

  
</body>


<footer style="background-color: #aaa; color: white; padding: 20px; text-align: center;">
    <div style="max-width: 100%; margin: 0 auto;">
        <!-- Responsive Image in Footer -->
        <?php
            // Define the image path
            $imagePathfooter1 = "files/50-organizer.png";

            // Check if the file exists before displaying it
            if (file_exists($imagePathfooter1)) {
                echo '<img src="' . $imagePathfooter1 . '" alt="Footer Image" class="responsive-footer-image">';
            } else {
                echo '<p>Footer image not found.</p>';
            }
        ?>
    </div>
    <p style="margin-top: 10px;">&copy; <?php echo date("Y"); ?> <h1>Kuantan Port International Conference 2024 <span>K-ICe 2024</span></h1></p>
</footer>

</html>
