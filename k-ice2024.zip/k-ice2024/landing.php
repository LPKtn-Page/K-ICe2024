
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Download PDF Files</title>
  <style>

 table {
  max-width: 100%; 
  margin: 0 auto;
  border-collapse: collapse;
   background-color: #f2f2f2;
}
th, td {
  border: 1px solid #dddddd;
 
   text-align: center; /* Horizontal centering */
            vertical-align: middle; /* Vertical centering */
  padding: 8px;
  
   word-wrap: break-word; /* Allows breaking and wrapping of long words */
           
}   

 td[rowspan] {
            vertical-align: middle; /* Vertical center alignment for merged cells */
            
             word-wrap: break-word; /* Allows breaking and wrapping of long words */
          
             width: 20%;
        } 
  

.center {
  	margin-left: auto;
  	margin-right: auto;
}

#nested {
  	background-color: #EEEEEE;
  	  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}




body               { 
  background:#aaa; 
  font:400 14px 'Calibri','Arial';
  padding:20px 0px 20px; 
  margin: 0;
    
    /*  display: flex;  */
      justify-content: center;
      align-items: center;
      height: 100vh; /* Full height of the viewport */
}

blockquote {
  color:white;
  text-align:center;
}

.container {
  background-color: #ddd;
  background-image: -moz-linear-gradient(#eee,#ddd);
  background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));    
  background-image: -webkit-linear-gradient(#eee, #ddd);
  background-image: -o-linear-gradient(#eee, #ddd);
  background-image: -ms-linear-gradient(#eee, #ddd);
  background-image: linear-gradient(#eee, #ddd);
  margin-top: -30px;
  padding-top: 30px;
  -moz-border-radius: 5px 5px 0 0;
  -webkit-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;     
}


.h3 {
  background-color: #ddd;
  background-image: -moz-linear-gradient(#eee,#ddd);
  background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ddd));    
  background-image: -webkit-linear-gradient(#eee, #ddd);
  background-image: -o-linear-gradient(#eee, #ddd);
  background-image: -ms-linear-gradient(#eee, #ddd);
  background-image: linear-gradient(#eee, #ddd);
  margin-top: -30px;
  padding-top: 30px;
  -moz-border-radius: 5px 5px 0 0;
  -webkit-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;     
}

 .responsive-image {
       max-width: 100%; /* Ensure image is responsive */
      height: auto;
    
       align-items: center;
      /*  background-color: #ddd; */
      
        justify-content: center;
    }
    
    .image-container {
  max-width: 100%; /* Adjust as needed */
  margin: 0 auto; /* Center the container */
   align-items: center;
       /*  background-color: #ddd; */
       justify-content: center;
       
        display: flex;
   
    text-align: center; /* Fallback for text alignment */
       
}



/* Footer Image Styling -->  */

    .responsive-footer-image {
        max-width: 80%; /* Limit max width for the footer */
        width: 100%; /* Responsive width */
        height: auto; /* Maintain aspect ratio */
        display: block; /* Remove extra space below the image */
        margin: 0 auto; /* Center the image in the footer */
         background-color: #ddd;
    }



  .stylish-hr {
            border: 0;
            height: 2px; /* Line thickness */
            background: linear-gradient(to right, #2e86c1, #ecf0f1, #2e86c1); /* Gradient color */
            margin: 20px 0; /* Space above and below the line */
            text-align: center; /* Fallback for text alignment */
        }






  </style>
  
 
  
</head>
<body class="h3">






<div class="h3"> 

        <table style="background-color:;  padding: 0px;  "> 
            
            <tr> 
                
                    <td id="nested" style="width:25%">
                    
                        <br>
                        <img src="files/50-logo.jpg" alt="Responsive Image" class="responsive-image" >
                    
                    </td>
                
                
                    <td id="nested" style="width:50%">
                    
                        <a style="color:darkblue;">    <h1>Kuantan Port International Conference 2024 <span >[ K-ICe 2024 ]</span> </h1></a>
                        <a style="color:#2e86c1; text-decoration: none;"> <h1 style="margin: 0; font-size: 2em;"><span>Sustainable Port Development :</span></h1> </a>
                        <a style="color:#2e86c1; text-decoration: none;"> <h1 style="margin: 0; font-size: 2em;"><span>Catalyst in Global Connectivity Towards Future Growth</span></h1> </a>
                    
                    </td>
                
                    <td id="nested" style="width:25%">
                    
                        <br>
                        <img src="files/50-lpktn.png" alt="Responsive Image" class="responsive-image">
                        <img src="files/50-kpc.png" alt="Responsive Image" class="responsive-image">
                        <img src="files/50-mima.png" alt="Responsive Image" class="responsive-image">
                        
                    </td>
                
            </tr>
        </table>

</div>
<hr class="stylish-hr">
 
 
<div class="container">
        
	<table>

        <span style="text-align:center;"><h1 >Conference  Notes </h1></span>

        <hr class="stylish-hr">
    
        <br>
				<tr>
				    <th id="nested" style:"width:3%;">Number</th>
				    <th id="nested" >Session / Title</th>
				    <th id="nested" >Moderator</th>
  					<th id="nested"style:"width:30%;">Panel</th>
  					<th id="nested" style:"width:10%;">Link</th>
  				</tr>
  				<tr>
  					<td>1</td>
  					  <td rowspan="3">Day I: Morning <br><strong>Global Partnership and Trand Dynamics Towards Industry's Sustainability</strong></td> <!-- Merge with the cell below -->
  					<td rowspan="3"><strong style="color:#6495ED;">Assoc, Prof. Eur. Ing. Ts. Ir. Dr. Syuhaida bt Ismail</strong>, <br><i>Director od Research</i> <br><b>Maritime Institute of Malaysia (MIMA)</b></td>
  					 <td><strong style="color:#6495ED;">Dato' Ong Chong Yi</strong>, <br><i>Executive Director</i> <br><b>Belt & Road Iniative Cauces for Asia Pasific (BRICAP)</b> </td>
  					<td><a href="https://drive.google.com/drive/folders/1NiVv1MwtLUI8v-Nh27Cc-upHSofju0Kp?usp=drive_link">download</a></td>
  					
  				</tr>
  				<tr>
  					<td>2</td>
  					
  					
  					<td><strong style="color:#6495ED;">Mr Mazlim bin Husin</strong>, <br><i>Chief Commersial Officer</i> <br><b>Kuantan Port Consurtium Sdn. Bhd. (KPC)</b> </td>
  					<td><a href="https://drive.google.com/drive/folders/1yY0ivstjr2loeincAg_1tHuI5VZN9YEV?usp=drive_link">download</a></td>
  					
  				</tr>
  				<tr>
  					<td>3</td>
  					
  					<td ><strong style="color:#6495ED;">Mr Omar Narrea</strong>,<br> <i>Economist & Research Affiliate</i> <br><b>Centre of China and Asia Pasific Studies</b> </td>
  					<td><a href="https://drive.google.com/file/d/1Hnwjv5WJ4-2TxgAZceLiqI_5Xra0XZcv/view?usp=sharing">download</a></td>
  					
  				
  				</tr>
  				<tr>
  					<td>4</td>
  					 <td rowspan="3">Day I: Afternoon <br><strong>Digitalisation and Technological Integration in Port Operations Towards Low-Zero Carbon Fuel</strong></td> <!-- Merge with the cell below -->
  					 <td rowspan="3"><strong style="color:#6495ED;">Capt. Subramaniam</strong>, <br><i>General Manager</i> <br><b>Port Klang Authority (PKA)</b></td>
  				
  					<td><strong style="color:#6495ED;">Mr Nazery Khalid</strong>,<br> Boustead Heavy Industrial Corporation Berhad</td>
  					<td><a href="https://drive.google.com/drive/folders/1yY0ivstjr2loeincAg_1tHuI5VZN9YEV?usp=drive_link">download</a></td>
  					
  				</tr>
  				
  				<tr>
  					<td>5</td>
  					
  					<td><strong style="color:#6495ED;">Mr Steve Hu</strong><br><i>Chief Technology Officer </i> <br><b>Alliance Steel (M) Sdn. Bhd.</b> </td>
  					<td><a href="https://drive.google.com/drive/folders/1yY0ivstjr2loeincAg_1tHuI5VZN9YEV?usp=drive_link">download</a></td>
  					
  				</tr>
  				
  				<tr>
  					<td>6</td>
  					 
  					<td><strong style="color:#6495ED;">Dr Izyan Munirah bt Mohd Zaideen</strong>, <br><i>Senior Lecturer, Faculty of Maritime Studies</i>  <br><b>Universiti Malaysia Terengganu (UMT)</b> </td>
  					<td><a href="https://drive.google.com/drive/folders/1yY0ivstjr2loeincAg_1tHuI5VZN9YEV?usp=drive_link">download</a></td>
  					
  				</tr>
  
  


  				
  			</table>
        
  
        

    <br>
  
  
 
       </div>

  
</body>


<footer  style=" color: black; padding: 20px; text-align: center;">
    <div id="container1" style="max-width: 80%; margin: 0 auto;">
        <!-- Responsive Image in Footer -->
        <?php
            // Define the image path
            $imagePathfooter1 = "files/50-organizer.png";

            // Check if the file exists before displaying it
            if (file_exists($imagePathfooter1)) {
                echo '<img src="' . $imagePathfooter1 . '" alt="Footer Image" class="responsive-footer-image">';
            } else {
                echo '<p>Footer image not found.</p>';
            }
        ?>
    </div>
    <p style="margin-top: 10px;"><h3>Kuantan Port International Conference ( K-ICe  <?php echo date("Y"); ?> )  &copy; LPKtn</h3></p>
</footer>

</html>
